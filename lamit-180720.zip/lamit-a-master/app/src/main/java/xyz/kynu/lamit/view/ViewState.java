package xyz.kynu.lamit.view;


public enum ViewState
{
	CONTENT, PROGRESS, OFFLINE, EMPTY
}
