package xyz.kynu.lamit.fragment;

import java.util.LinkedList;
import java.util.List;
import java.util.Objects;

//import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;


public class TaskFragment extends Fragment {
    private final Object mLock = new Object();
    private Boolean mReady = false;
    private final List<Runnable> mPendingCallbacks = new LinkedList<>();

/*
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
*/

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        synchronized (mLock) {
            mReady = true;
            int pendingCallbacks = mPendingCallbacks.size();
            while (pendingCallbacks-- > 0) {
                Runnable runnable = mPendingCallbacks.remove(0);
                runNow(runnable);
            }
        }
    }


    @Override
    public void onDetach() {
        super.onDetach();
        synchronized (mLock) {
            mReady = false;
        }
    }


    void runTaskCallback(Runnable runnable) {
        if (mReady) runNow(runnable);
        else addPending(runnable);
    }

/*
    protected void executeTask(AsyncTask<Void, ?, ?> task) {
        // Use AsyncTask.THREAD_POOL_EXECUTOR or AsyncTask.SERIAL_EXECUTOR
        task.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
    }
*/

    private void runNow(Runnable runnable) {
        Objects.requireNonNull(getActivity()).runOnUiThread(runnable);
    }


    private void addPending(Runnable runnable) {
        synchronized (mLock) {
            mPendingCallbacks.add(runnable);
        }
    }
}
